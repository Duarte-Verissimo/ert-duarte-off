# Ficheiros corrigidos — Labs 9 e 10

## Correções feitas

1. Removido o `REQ-001` dos testes principais.
2. Substituído o antigo TC-001 por um teste de evidência de DR ligado a `REQ-002`.
3. Removidas referências a infraestrutura/contactos nos cenários principais.
4. Adicionado `# Requisitos testados:` antes de cada cenário BDD.
5. Atualizadas as matrizes de rastreabilidade.
6. Atualizado o plano de testes com nota de scope.
7. Atualizado o documento AC/DoD com regra de coerência com scope implementado.

## Ficheiros a substituir no repo

```txt
docs/test_cases.md
docs/traceability_req_tc.md
bdd/features/lab9.feature
docs/test_plan.md
docs/traceability_req_ac_tc.md
docs/ac_dod_updates.md
```
